<template>
  <footer>
    <p>@ 图书管理系统</p>
  </footer>
</template>

<script>
  export default{
    data() {
      return {}
    }
  }
</script>

<style scoped>
  p {
    text-align: center;
  }
</style>
