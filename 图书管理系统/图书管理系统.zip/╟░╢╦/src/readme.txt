route:  指的是单个的路由
routes: 多个路由的集合
router: 路由器
router会去routes中查找route

将菜单保存在vuex中（store/index.js）